<?php
	/*
	Template Name: Descontos
	 */
	get_header();
	get_template_part('includes/pages/empresas');
	get_footer();