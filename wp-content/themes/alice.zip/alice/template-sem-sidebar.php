<?php
	/*
		template name: Sem Sidebar
	*/
	get_header();
	get_template_part('includes/pages/sem-sidebar');
	get_footer();