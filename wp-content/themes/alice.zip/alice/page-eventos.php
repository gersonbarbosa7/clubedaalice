<?php
	/*
	Template Name: EVENTOS
	 */
	get_header();
	get_template_part('includes/pages/eventos');
	get_footer();