<?php 
	get_header();
	get_template_part('includes/pages/listagem');
	get_footer();