<div id="newsletter">
	<div id="newsletter-container">
		<hgroup>
			<h2>FIQUE LIGADA NO CLUBE DA ALICE.</h2>
		</hgroup>
		<form action="#" class="form-inline" method="post" target="_blank">
			<input type="email" placeholder="PREENCHA SEU EMAIL" name="email">
			<button type="submit">
				<i class="fa fa-thumbs-up"></i>
				EU QUERO
			</button>
			<div class="clearfix"></div>
		</form>
	</div>
</div>