<div class="widget titulo-com-faixas">
	<header>
		<h3><span>SIGA-NOS</span></h3>	
	</header>
	<div class="widget-content">
		<div class="fb-page" data-href="https://www.facebook.com/clubedaaliceoficial/?ref=ts&amp;fref=ts" data-small-header="false" data-adapt-container-width="true" data-hide-cover="false" data-show-facepile="false"><div class="fb-xfbml-parse-ignore"><blockquote cite="https://www.facebook.com/clubedaaliceoficial/?ref=ts&amp;fref=ts"><a href="https://www.facebook.com/clubedaaliceoficial/?ref=ts&amp;fref=ts">Clube da Alice</a></blockquote></div></div>
	</div>
</div>