<!--container-->
</div>
<section id="eventos-subheader">
	<header class="container">
		<hgroup>
			<h2>
				PRÓXIMOS EVENTOS DO CLUBE DA ALICE
			</h2>
			<hr>
		</hgroup>
	</header>
	<div class="container main">
		<?php get_template_part('includes/modules/module', 'datas-eventos'); ?>
	</div>
</section>
<div class="container">
	<?php get_template_part('includes/modules/module', 'banner'); ?>
	<?php get_template_part('includes/modules/module', 'eventos'); ?>