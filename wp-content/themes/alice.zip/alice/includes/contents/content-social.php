<?php global $icon, $value; ?>
<li>
	<a href="<?php echo $value;?>" target="_blank" title="<?php echo strtoupper($icon);?>">
		<i class="fa fa-<?php echo $icon;?>"></i>
	</a>
</li> 