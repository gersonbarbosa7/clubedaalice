<li>
	<a href="https://api.addthis.com/oexchange/0.8/forward/facebook/offer?url=<?php the_permalink(); ?>&pubid=ra-5297770d2427f2a7&ct=1&title=<?php the_title(); ?>&pco=tbxnj-1.0" title="Compartilhar no Facebook" target="_blank">
		<i class="fa fa-facebook"></i>
	</a>
</li>
<li>
	<a href="https://api.addthis.com/oexchange/0.8/forward/twitter/offer?url=<?php the_permalink(); ?>&pubid=ra-5297770d2427f2a7&ct=1&title=<?php the_title(); ?>&pco=tbxnj-1.0" title="Compartilhar no Twitter" target="_blank">
		<i class="fa fa-twitter"></i>
	</a>
</li>
<li>
	<a href="https://api.addthis.com/oexchange/0.8/forward/google_plusone_share/offer?url=<?php the_permalink(); ?>&pubid=ra-5297770d2427f2a7&ct=1&title=<?php the_title(); ?>&pco=tbxnj-1.0" title="Compartilhar no Google Plus" target="_blank">
		<i class="fa fa-google-plus"></i>
	</a>
</li>
<li>
	<a href="https://api.addthis.com/oexchange/0.8/forward/pinterest/offer?url=<?php the_permalink(); ?>&pubid=ra-5297770d2427f2a7&ct=1&title=<?php the_title(); ?>&pco=tbxnj-1.0" title="Compartilhar no Pinterest" target="_blank">
		<i class="fa fa-pinterest"></i>
	</a>
</li>