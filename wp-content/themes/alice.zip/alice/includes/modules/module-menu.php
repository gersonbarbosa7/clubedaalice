	<div class="menu-principal selos hidden-xs">		
		<div class="container">
			<nav>
				<ul>
					<li>
						<a href="<?php echo home_url('/blog'); ?>" title="Clube da Alice - Blog">
							<img src="<?php echo IMG; ?>icones/alice-bottom-1.png" alt="Clube da Alice - Blog" title="Clube da Alice - Blog">Blog
						</a>
					</li>

					<li>
						<a href="<?php echo home_url('/nossos-eventos'); ?>" title="Clube da Alice - Eventos">
							<img src="<?php echo IMG; ?>icones/alice-bottom-2.png" alt="Clube da Alice - Eventos" title="Clube da Alice - Eventos">Eventos
						</a>
					</li>

					<li>
						<a href="https://vimeo.com/clubedaalice" target="_blank" title="Clube da Alice - Vídeos">
							<img src="<?php echo IMG; ?>icones/alice-bottom-3.png" alt="Clube da Alice - Vídeos" title="Clube da Alice - Vídeos">Vídeos
						</a>
					</li>	

					<li>
						<a href="<?php echo home_url('/descontos'); ?>" title="Clube da Alice - Descontos">
							<img src="<?php echo IMG; ?>icones/alice-bottom-4.png" alt="Clube da Alice - Descontos" title="Clube da Alice - Descontos">Descontos
						</a>
					</li>			

					<li>
						<a href="<?php echo home_url('/cda_cupom'); ?>" title="Clube da Alice - Cupons">
							<img src="<?php echo IMG; ?>icones/alice-bottom-5.png" alt="Clube da Alice - Descontos" title="Clube da Alice - Descontos">Cupons de Descontos
						</a>
					</li>



				</ul>
			</nav>
		</div>		
	</div>