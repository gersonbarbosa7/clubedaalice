<div id="newsletter">
	<div id="newsletter-container">
		<hgroup>
			<h2>FIQUE LIGADA NO CLUBE DA ALICE.</h2>
			<h3>RECEBA AS NOTÍCIAS, NOVIDADES E EVENTOS DA ALICE NO SEU E-MAIL</h3>
		</hgroup>
		<form action="#" class="form-inline" method="post" target="_blank">
			<input type="email" placeholder="Preencha seu melhor e-mail" name="email">
			<button type="submit">
				<i class="fa fa-thumbs-up"></i>
				Eu quero Receber
			</button>
			<div class="clearfix"></div>
		</form>
	</div>
</div>