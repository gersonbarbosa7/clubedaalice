<div id="agenda">
	<a target="blank" href="http://www.happythings.com.br/pd-266020-agenda-clube-da-alice.html?ct=&p=1&s=1" title="Agenda Clube da Alice" alt="Compre já sua agenda da Alice">
		<img src="<?php echo IMG; ?>agenda.png" title="" alt="">
	</a>
</div>