<?php
	get_header();
	get_template_part('includes/pages/pagina');
	get_footer();