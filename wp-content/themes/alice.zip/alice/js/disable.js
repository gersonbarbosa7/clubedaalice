jQuery(document).ready(function() {
	jQuery('#acf-field-post_views_count').prop('disabled', 1);
})
