<?php 
	get_header();
	get_template_part('includes/pages/categoria');
	get_footer();