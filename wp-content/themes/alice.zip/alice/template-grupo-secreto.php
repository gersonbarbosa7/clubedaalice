<?php 
/*
	Template name: Discourse // Grupo Secreto
*/
get_header(); ?>
<div id='discourse-comments'></div>
<?php 
get_footer(); ?>